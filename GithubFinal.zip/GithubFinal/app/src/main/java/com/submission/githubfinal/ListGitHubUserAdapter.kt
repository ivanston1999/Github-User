package com.submission.githubfinal

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide


class ListGitHubUserAdapter(private val listGitHubUser: List<ItemsItem>):RecyclerView.Adapter<ListGitHubUserAdapter.ViewHolder>(){

    override fun onCreateViewHolder(viewGroup: ViewGroup, viewType: Int) =
        ViewHolder(LayoutInflater.from(viewGroup.context).inflate(R.layout.item_user, viewGroup, false))

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val users = listGitHubUser[position]
        holder.tvName.text = users.login
        Glide.with(holder.itemView.context)
            .load(users.avatarUrl)
            .circleCrop()
            .into(holder.profile)

        holder.itemView.setOnClickListener{
            val intentDetail = Intent(holder.itemView.context, UserDetailActivity::class.java)
            intentDetail.putExtra(UserDetailActivity.USER, users.login)
            holder.itemView.context.startActivity(intentDetail)
        }
    }

    override fun getItemCount() = listGitHubUser.size

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvName : TextView = view.findViewById(R.id.tv_username)
        val profile : ImageView = view.findViewById(R.id.iv_user)
    }

}