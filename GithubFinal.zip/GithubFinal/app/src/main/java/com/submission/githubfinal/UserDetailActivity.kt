package com.submission.githubfinal


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import com.submission.githubfinal.databinding.ActivityUserDetailBinding

class UserDetailActivity : AppCompatActivity() {
    companion object {
        const val USER = "key_user"

        @StringRes
        private val TAB = intArrayOf(
            R.string.tab1,
            R.string.tab2
        )
    }

    private lateinit var binding: ActivityUserDetailBinding
    private lateinit var viewModel: DetailViewModel



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityUserDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val username = intent.getStringExtra(USER)
        val bundle = Bundle()
        bundle.putString(USER, username)

        viewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(
            DetailViewModel::class.java
        )

        val userLogin = intent.getStringExtra(USER)
        binding.profileName.text = userLogin

        val PagerAdapter = PagerAdapter(this)
        PagerAdapter.username = userLogin.toString()

        val viewPager: ViewPager2 = findViewById(R.id.viewPager)
        viewPager.adapter = PagerAdapter

        val tabs: TabLayout = findViewById(R.id.tabLayout)
        TabLayoutMediator(tabs, viewPager) { tabs, position ->
            tabs.text = resources.getString(TAB[position])
        }.attach()

        supportActionBar?.elevation = 0f

        if (userLogin != null) {
            showLoading(true)
            viewModel.getUserDetail(userLogin)
            showLoading(false)
        }
        viewModel.detailUser.observe(this) { detailUser ->
            setDetailUser(detailUser)
        }

        viewModel.isLoading.observe(this) {
            showLoading(it)
        }
    }

    private fun setDetailUser(Name: DetailUserResponse) {
        Glide.with(this@UserDetailActivity)
            .load(Name.avatarUrl)
            .into(binding.profileImage)
        binding.profileName.text = Name.login
        binding.profileUsername.text = Name.name
        binding.totalFollowers.text = Name.followers.toString()
        binding.totalFollowing.text = Name.following.toString()


    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar2.visibility = View.VISIBLE
        } else {
            binding.progressBar2.visibility = View.GONE
        }
    }
}
