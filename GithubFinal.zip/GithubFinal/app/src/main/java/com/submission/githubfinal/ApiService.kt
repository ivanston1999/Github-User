package com.submission.githubfinal

import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.Path
import retrofit2.http.Query

interface ApiService {
    @GET("search/users")
    @Headers("Authorization: token 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")
    fun getGitHubUser(
        @Query("q") query: String
    ): Call<GithubUserResponse>

    @GET("users/{username}")
    @Headers("Authorization: token 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")
    fun getDetailUser(@Path("username") username: String
    ): Call<DetailUserResponse>

    @GET("users/{username}/followers")
    @Headers("Authorization: token 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")
    fun getFollowers(@Path("username") username: String
    ): Call<List<ItemsItem>>

    @GET("users/{username}/following")
    @Headers("Authorization: token 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")
    fun getFollowing(@Path("username") username: String
    ): Call<List<ItemsItem>>


}